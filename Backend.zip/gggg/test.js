process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";


const express = require('express');
const axios = require('axios');
var bodyParser = require('body-parser');


const app = express();
const port = 5000;   
app.use(bodyParser.urlencoded({ extended: false }))

app.use(bodyParser.json())

// this for get 
app.post('/getbooks', (req, res) => {

  var data = JSON.stringify({
      "collection": "book",
      "database": "Mean",
      "dataSource": "Cluster1"
  });
  
  var config = {
      method: 'post',
      url: 'https://ap-south-1.aws.data.mongodb-api.com/app/data-iepguef/endpoint/data/v1/action/find',
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Request-Headers': '*',
        'api-key': 'UC2pL2IwDSLJ7KysRVT4og3uRZQMPhJJL7QjQgbw93rYBBijRtcB7aDm5VfHhpTi',
      },
      data: data
  };
  
  axios(config)
      .then(function (response) {
          console.log(JSON.stringify(response.data));
          res.status(200).send(response.data)
      })
      .catch(function (error) {
          console.log(error);
      });
  
});


// this for delete

app.post('/deletebooks1', (req, res) => {
const{name}=req.body;
  var data = JSON.stringify({
      "collection": "book",
      "database": "Mean",
      "dataSource": "Cluster1",
      
        "filter": {"name":name} 
      
  });
  
  var config = {
      method: 'post',
      url: 'https://ap-south-1.aws.data.mongodb-api.com/app/data-iepguef/endpoint/data/v1/action/deleteOne',
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Request-Headers': '*',
        'api-key': 'UC2pL2IwDSLJ7KysRVT4og3uRZQMPhJJL7QjQgbw93rYBBijRtcB7aDm5VfHhpTi',
      },
      data: data
  };
  
  axios(config)
      .then(function (response) {
          console.log(JSON.stringify(response.data));
          res.status(200).send(response.data)
      })
      .catch(function (error) {
          console.log(error);
      });
  
});

// this for post

app.post('/addbook', (req, res) => { 
  const{ name,age}=req.body;

  var data = JSON.stringify({
      "collection": "book",
      "database": "Mean",
      "dataSource": "Cluster1",
      "document":{
        "name":name,
        "age": age
      }
  });
  
  var config = {
      method: 'post',
      url: 'https://ap-south-1.aws.data.mongodb-api.com/app/data-iepguef/endpoint/data/v1/action/insertOne',
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Request-Headers': '*',
        'api-key': 'gDQDmjon4oI9ds8Gt7oYZLngo8Id0TRdZsV2kwmRS3BRHcd07kKsUcMyypJBviIV',
      },
      data: data
  };
  
  axios(config)
      .then(function (response) {
          console.log(JSON.stringify(response.data));
          res.status(200).send("Document added successfully")
      })
      .catch(function (error) {
          console.log(error);
      });
  
});

// this for update

app.post('/updatebook', (req, res) => { 
  const{ name,age}=req.body;

  var data = JSON.stringify({
      "collection": "book",
      "database": "Mean",
      "dataSource": "Cluster1",
      "filter": { "name": name },
      "update": { "$set": { "age": age } }
  });
  
  var config = {
      method: 'post',
      url: 'https://ap-south-1.aws.data.mongodb-api.com/app/data-iepguef/endpoint/data/v1/action/updateOne',
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Request-Headers': '*',
        'api-key': 'gDQDmjon4oI9ds8Gt7oYZLngo8Id0TRdZsV2kwmRS3BRHcd07kKsUcMyypJBviIV',
      },
      data: data
  };
  
  axios(config)
      .then(function (response) {
          console.log(JSON.stringify(response.data));
          res.status(200).send(response.data)
      })
      .catch(function (error) {
        console.log(error);
        res.status(500).send("Internal Server Error");

      });
  
});
  
// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});